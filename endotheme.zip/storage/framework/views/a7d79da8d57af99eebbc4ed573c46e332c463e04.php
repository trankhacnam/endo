<h2>Mail Contact !</h2> <br><br> 

 

You received an email from : <?php echo e($name); ?> <br><br> 

 

User details: <br><br> 

 

Name:  <?php echo e($name); ?><br> 

Email:  <?php echo e($email); ?><br>  

Subject:  <?php echo e($subject); ?><br> 

Message:  <?php echo $subject; ?><br><br> 

 

Thanks <?php /**PATH D:\xampp\htdocs\endo\resources\views/contactMail.blade.php ENDPATH**/ ?>